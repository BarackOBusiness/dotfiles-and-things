local playsession = {
	{"HYPPS", {215740}},
	{"wildgrim", {170484}},
	{"ManuelG", {145439}},
	{"seeyorise", {138960}},
	{"Dark1244", {105552}},
	{"adam1285", {18877}},
	{"Timo-Herzebrock", {35370}}
}
return playsession