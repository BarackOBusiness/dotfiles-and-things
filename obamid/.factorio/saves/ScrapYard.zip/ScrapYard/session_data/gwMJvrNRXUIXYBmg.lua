local playsession = {
	{"cogito123", {360066}},
	{"TiTaN", {501495}},
	{"Menander", {104637}},
	{"Lulaidon", {480370}},
	{"Leverage", {260168}},
	{"Elements", {16522}},
	{"MuddledBox", {292322}},
	{"raskl", {154969}},
	{"MFH", {339492}},
	{"Loriangrei", {3108}},
	{"vad7ik", {183871}},
	{"realDonaldTrump", {1086}},
	{"kRo1", {510}},
	{"cchpucky", {1262}},
	{"Dysonhive", {248421}},
	{"facere", {289884}},
	{"spikeolas", {155943}},
	{"762x51mm", {78594}},
	{"Malorie_sXy", {219988}},
	{"everLord", {170761}},
	{"Olekplane1", {13462}}
}
return playsession