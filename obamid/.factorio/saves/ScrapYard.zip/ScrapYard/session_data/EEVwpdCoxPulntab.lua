local playsession = {
	{"Reyand", {24858}},
	{"Ed9210", {1507}},
	{"Menander", {228421}},
	{"der_Nase_nach", {218953}},
	{"КОММУНИСТ", {1673}},
	{"ehwoghd", {17957}},
	{"Jawgod", {4425}},
	{"KIRkomMAX", {102683}},
	{"RonnDlear", {89106}},
	{"sj3020", {37927}},
	{"Giatros", {22101}},
	{"tangoindiamike", {31064}},
	{"Akiane", {3542}}
}
return playsession