local playsession = {
	{"zarlo5899", {62354}},
	{"Clickman", {215062}},
	{"MontrealCrook", {214757}},
	{"mewmew", {209954}},
	{"LegionMammal978", {1728}},
	{"tj12134", {9851}},
	{"banakeg", {165770}},
	{"Tony_2083", {146121}},
	{"davidbutora", {119800}},
	{"adamm17", {36686}},
	{"Lestibornes", {68551}},
	{"aniche", {49185}},
	{"Aceriterium_A", {1747}},
	{"OmegaLunch", {39003}},
	{"realDonaldTrump", {28016}},
	{"CorReqT", {21630}}
}
return playsession