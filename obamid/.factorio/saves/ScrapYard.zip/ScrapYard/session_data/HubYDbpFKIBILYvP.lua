local playsession = {
	{"den4ik_reg", {5536}},
	{"___Ohr___", {102278}},
	{"arisgr", {94953}},
	{"Brathahn", {78818}},
	{"bogg19", {52156}},
	{"fargas", {19343}},
	{"Duchesko", {36227}}
}
return playsession