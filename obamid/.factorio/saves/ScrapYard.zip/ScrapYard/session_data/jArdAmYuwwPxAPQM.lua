local playsession = {
	{"Gerkiz", {279947}},
	{"jordyys_", {660}},
	{"TiTaN", {155486}},
	{"Ardordo", {7540}},
	{"JailsonBR", {72834}},
	{"A-l-a-n", {21485}},
	{"Nikkichu", {46909}}
}
return playsession