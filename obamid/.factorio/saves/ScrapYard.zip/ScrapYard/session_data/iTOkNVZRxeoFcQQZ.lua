local playsession = {
	{"mewmew", {83087}},
	{"MaFiX", {230662}},
	{"devilerik", {23318}},
	{"Dubber", {19617}},
	{"Amker", {2328}},
	{"Zory", {125332}},
	{"Vuldunobetro", {438188}},
	{"dpoba", {1564312}},
	{"HardcoreRocco", {17610}},
	{"J7cuxolor", {78950}},
	{"raipenahk", {47662}},
	{"nik12111", {2436}},
	{"Giatros", {20214}},
	{"CrazyCrabEater", {2114}},
	{"Zorky", {5714}},
	{"Gerkiz", {77153}},
	{"pickles28", {3792}},
	{"PolanStronk", {4717}},
	{"rocifier", {12700}}
}
return playsession