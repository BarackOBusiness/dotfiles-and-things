local playsession = {
	{"Gerkiz", {6930}},
	{"Ardordo", {144997}},
	{"realDonaldTrump", {3290}},
	{"cawsey21", {229065}},
	{"snoetje", {51000}},
	{"rlidwka", {150221}},
	{"Guitoune", {174913}},
	{"Arin", {148665}},
	{"bcap", {94097}},
	{"facere", {78535}},
	{"dog80", {4492}}
}
return playsession