local playsession = {
	{"Hitman451", {1007960}},
	{"Krono", {997475}},
	{"eifel", {1756}},
	{"Menander", {33041}},
	{"realDonaldTrump", {956364}},
	{"cabb99", {2990}},
	{"dragon6373", {575476}},
	{"Ed9210", {834549}},
	{"Miteone", {138419}},
	{"kkook30", {216}},
	{"Bunyjr", {1284}},
	{"InphinitePhractals", {425536}},
	{"hendrikjk", {3694}},
	{"Factorian12321", {243864}},
	{"pepopepo201", {155148}},
	{"rocifier", {72614}},
	{"Kaskelotti", {3223}}
}
return playsession