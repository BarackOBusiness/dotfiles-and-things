local playsession = {
	{"Kamyk", {23894}},
	{"dorpdorp", {56879}},
	{"Zymoran", {70513}},
	{"Clythoris", {56186}},
	{"Timfee", {63487}},
	{"Nikkichu", {50555}},
	{"Katalizator", {54157}},
	{"kusimir", {24098}},
	{"banakeg", {23350}},
	{"VidelPC", {22563}},
	{"adam1285", {22047}},
	{"ktrc199", {21812}},
	{"ImRock", {3564}},
	{"loutanifi", {16451}},
	{"Firewall5000", {10846}},
	{"rlidwka", {9265}},
	{"ClydeFrog002", {7284}},
	{"Seelentherapeut", {6410}},
	{"Krazek", {1813}},
	{"bobbythebob12", {3246}}
}
return playsession