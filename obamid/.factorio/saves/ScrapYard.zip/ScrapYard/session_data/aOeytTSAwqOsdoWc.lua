local playsession = {
	{"Flashbacks", {143833}},
	{"wildgrim", {143141}},
	{"rlidwka", {133033}},
	{"Gerkiz", {137825}},
	{"DerFactorioNinja", {1399}},
	{"ColonelWill", {13351}},
	{"Dimtree", {59316}},
	{"LATBOY", {51657}},
	{"Schwert3000", {8974}}
}
return playsession