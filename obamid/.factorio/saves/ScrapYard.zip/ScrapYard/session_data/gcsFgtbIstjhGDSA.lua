local playsession = {
	{"grbr", {107980}},
	{"ManuelG", {100976}},
	{"autopss", {103621}},
	{"matam666", {102697}},
	{"Malorie_sXy", {91492}},
	{"xkillolz", {1437}},
	{"___Ohr___", {40948}}
}
return playsession