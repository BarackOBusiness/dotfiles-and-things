local playsession = {
	{"Menander", {693705}},
	{"rocifier", {714009}},
	{"adein4", {629}},
	{"snaodrn", {3472}},
	{"piskamoruska", {2446}},
	{"wot_tak", {8923}},
	{"Nalleknas", {1450}},
	{"15944831778", {3523}},
	{"Fexx", {736}},
	{"Lotek", {2138}},
	{"Zory", {170836}},
	{"KIRkomMAX", {1307}}
}
return playsession