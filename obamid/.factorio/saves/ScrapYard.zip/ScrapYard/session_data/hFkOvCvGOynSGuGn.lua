local playsession = {
	{"mewmew", {1988062}},
	{"westbroma", {12061592}},
	{"flooxy", {6521776}},
	{"Zorky", {4147724}},
	{"Akhrem", {11871579}},
	{"dpoba", {5510457}},
	{"jack9761", {101614}},
	{"NekoBaron", {327793}},
	{"Spaceman-Spiff", {176467}},
	{"Catbert", {41609}},
	{"Snowpig7u", {10065}},
	{"morcup", {27359}},
	{"adieclay", {528480}},
	{"KevinTheRed", {33668}},
	{"Phil535", {2130410}},
	{"snoetje", {7043374}},
	{"CarlosDiamanti", {63332}},
	{"Meredy", {101075}},
	{"wilm", {124984}},
	{"userguide", {109596}}
}
return playsession