local playsession = {
	{"LtDerp", {143766}},
	{"tyssa", {143599}},
	{"Mr_Trump", {142716}},
	{"Tyvix", {142589}},
	{"GuidoCram", {103320}},
	{"WorldofWarIII", {142020}},
	{"Darknut12", {33777}},
	{"ServalKitty", {140094}},
	{"zakky0919", {128480}},
	{"peterses123", {125926}},
	{"olee90", {106544}},
	{"remarkablysilly", {103885}},
	{"Dr.Shrimp", {93698}},
	{"rektb16", {54935}},
	{"Weizenbrot", {18008}},
	{"Rotary255", {43232}},
	{"zhangguo1981", {20896}}
}
return playsession