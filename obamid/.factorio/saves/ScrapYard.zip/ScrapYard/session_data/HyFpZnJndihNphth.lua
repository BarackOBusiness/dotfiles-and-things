local playsession = {
	{"Sylphoid", {107767}},
	{"Dr. Idiot", {107257}},
	{"rayijin", {106986}},
	{"Maravel", {98139}},
	{"Terarink", {95101}},
	{"Danyusun", {84131}},
	{"bezoya", {2849}}
}
return playsession