local playsession = {
	{"TimSekys", {252175}},
	{"PogomanD", {117059}},
	{"MrChickan", {252677}},
	{"mad58max", {287708}},
	{"EricForce", {287603}},
	{"rocifier", {278748}},
	{"Cyguy28", {278333}},
	{"DreadnEbon", {277283}},
	{"polishdude20", {27580}},
	{"Hydroelectric", {222789}},
	{"Menander", {182325}},
	{"LotA", {1798}},
	{"ottoX4", {5091}},
	{"Immo", {167748}},
	{"Hakaider", {5141}},
	{"slikasandr", {44940}},
	{"SrSticks", {6519}},
	{"muchbetter321", {107057}},
	{"WaveOfBabies", {2209}},
	{"CallMeTaste", {22012}}
}
return playsession