local playsession = {
	{"Karden_Atreides", {359712}},
	{"paketikk", {170481}},
	{"Copperbotte", {338}},
	{"StillSingle", {8406}},
	{"Krono", {205505}},
	{"jbox1", {188177}},
	{"KIRkomMAX", {101393}},
	{"Qwa7", {1471}},
	{"puuupedis", {1204}},
	{"Aero182218", {11800}},
	{"NASER", {2833}}
}
return playsession