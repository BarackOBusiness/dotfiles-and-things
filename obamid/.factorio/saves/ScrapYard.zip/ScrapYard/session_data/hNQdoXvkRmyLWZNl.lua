local playsession = {
	{"unixfreak", {358908}},
	{"nizzy", {8229}},
	{"svjatosha", {216129}},
	{"Chico75", {353311}},
	{"phanton5000", {319201}},
	{"_Lightning", {348097}},
	{"Ed9210", {342344}},
	{"Taylor-Swift", {3780}},
	{"TheWearyGamer", {322750}},
	{"Monkeyboy1024", {38516}},
	{"NBtrain", {1347}},
	{"Markle", {126902}},
	{"mpovas", {110722}},
	{"RugbyHunter", {101226}},
	{"sjkasy", {23971}},
	{"paulicus", {41755}}
}
return playsession