local playsession = {
	{"Nate66873", {179881}},
	{"Plawerth", {175155}},
	{"Makmel", {120721}},
	{"KIRkomMAX", {101257}},
	{"edelos997", {3194}},
	{"Rayeth", {71837}},
	{"15944831778", {67643}},
	{"bbc26rus", {3306}},
	{"sasha21168", {7125}},
	{"PolanStronk", {33751}},
	{"beranabus", {22982}},
	{"Bokrug", {14578}},
	{"AkonDR", {6613}}
}
return playsession