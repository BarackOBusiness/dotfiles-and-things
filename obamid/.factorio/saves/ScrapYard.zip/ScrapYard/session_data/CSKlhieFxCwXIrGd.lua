local playsession = {
	{"illiander42", {4815}},
	{"loutanifi", {233845}},
	{"Nalleknas", {272565}},
	{"Anton-miko", {1369}},
	{"Houdi", {376589}},
	{"BamBamPalli", {217476}},
	{"JuanMore", {176304}},
	{"robertkruijt", {308064}},
	{"BlackShit71", {3382}},
	{"LandOfBol", {115324}},
	{"Firewall5000", {37203}},
	{"chillout85", {25741}},
	{"Gerkiz", {4049}},
	{"Seelentherapeut", {32321}}
}
return playsession