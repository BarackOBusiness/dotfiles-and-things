local playsession = {
	{"MeggalBozale", {107596}},
	{"AFD", {101177}},
	{"sd205521", {2139}},
	{"Sad-Cass", {81344}},
	{"tmoneyfizzle", {80103}},
	{"tokastar", {6738}},
	{"NekoBaron", {65368}}
}
return playsession