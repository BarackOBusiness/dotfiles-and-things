local playsession = {
	{"tickterd", {101638}},
	{"chronodekar", {3127}},
	{"bigot", {1984}},
	{"firstandlast", {1785}}
}
return playsession