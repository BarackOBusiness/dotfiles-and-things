local playsession = {
	{"matam666", {251477}},
	{"mastah_mind", {108855}},
	{"rope", {833}},
	{"Mythid", {4673}},
	{"johancakehole", {101542}},
	{"bajarz33", {2086}},
	{"Miteone", {913}},
	{"762x51mm", {1462}},
	{"Hitman451", {2418}}
}
return playsession