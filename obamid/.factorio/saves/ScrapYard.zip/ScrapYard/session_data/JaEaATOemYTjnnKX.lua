local playsession = {
	{"Karden_Atreides", {65859}},
	{"Ed9210", {1086}},
	{"amoniumhydroxid", {8559}},
	{"Rameka", {348}},
	{"wildgrim", {4820}},
	{"Pyroman69", {35485}},
	{"aleksander", {19548}},
	{"Genocide_General", {150033}},
	{"Krono", {71046}},
	{"iceskaarj", {55167}},
	{"Flashbacks", {4610}}
}
return playsession