local playsession = {
	{"WorldofWarIII", {71802}},
	{"SandHome", {4667}},
	{"MrJSelig", {41705}},
	{"Nalleknas", {26160}}
}
return playsession