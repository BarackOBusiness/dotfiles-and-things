local playsession = {
	{"mewmew", {718}},
	{"mrc5507", {215180}},
	{"JerkTurk", {37835}},
	{"Zory", {140731}},
	{"MeggalBozale", {135929}},
	{"Tech_Master", {122590}},
	{"ksb4145", {53901}},
	{"abnoeh", {23793}},
	{"Luca-Brasi", {7050}},
	{"Ska-Dee", {403}},
	{"COOL-ITEM", {46702}},
	{"StormBreaker", {44222}},
	{"Jhumekes", {8185}}
}
return playsession