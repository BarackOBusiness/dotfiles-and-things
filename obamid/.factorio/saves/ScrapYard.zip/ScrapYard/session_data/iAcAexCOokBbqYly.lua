local playsession = {
	{"iceskaarj", {30459}},
	{"Menander", {1181262}},
	{"Fexx", {7121}},
	{"rocifier", {412159}},
	{"mcskiny", {3109}},
	{"Dressi", {160451}},
	{"synclind", {38235}},
	{"ronnaldy", {290200}},
	{"CrazyCrabEater", {771441}},
	{"maigiee", {762109}},
	{"InphinitePhractals", {689851}},
	{"Hitman451", {368909}},
	{"Zarf42", {6241}},
	{"Parkouralvoil", {304972}},
	{"PogomanD", {281254}},
	{"tmoneyfizzle", {10467}},
	{"bananasplo", {23327}}
}
return playsession