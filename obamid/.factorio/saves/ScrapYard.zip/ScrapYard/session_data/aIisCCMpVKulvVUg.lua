local playsession = {
	{"Menander", {92079}},
	{"cawsey21", {6271}},
	{"MrCube", {628}},
	{"SparzianII", {300155}},
	{"facere", {560}},
	{"4xBen", {214377}},
	{"Croustibax", {205656}},
	{"Podonkov", {987}},
	{"dazonker", {11275}},
	{"zarlo5899", {4372}},
	{"exabyte", {2861}},
	{"MisterBabou", {4473}}
}
return playsession