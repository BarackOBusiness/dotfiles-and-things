local playsession = {
	{"RES231", {71977}},
	{"mewmew", {71230}},
	{"captcougar1969", {70540}},
	{"tmoneyfizzle", {5206}},
	{"darkmatter2222", {65728}},
	{"David_686", {56637}},
	{"Elrael", {63362}},
	{"switchz", {52881}},
	{"gonzakong", {53974}},
	{"jrz126", {5849}},
	{"panzerpenguin", {3165}},
	{"OmegaLunch", {39042}},
	{"banakeg", {29164}},
	{"CustomSocks", {16822}},
	{"FluidMotion", {15531}},
	{"Conor0709", {5661}}
}
return playsession