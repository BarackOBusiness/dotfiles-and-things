local playsession = {
	{"Nerazin", {287934}},
	{"Kamyk", {286995}},
	{"ManuelG", {74643}},
	{"phill3333", {210307}},
	{"sobitome", {267696}},
	{"Ruslan_kc", {272039}},
	{"maxym", {1046}},
	{"rlidwka", {89807}},
	{"CmdrRat", {255477}},
	{"ltbloodshed", {201681}},
	{"rantell", {247328}},
	{"D0pex", {230987}},
	{"cyrkon", {1880}},
	{"AlanSYNC", {210287}},
	{"Struppi", {196322}},
	{"Wolf21", {3344}},
	{"trololzz", {171373}},
	{"seeyorise", {20236}},
	{"Owen87", {17438}}
}
return playsession