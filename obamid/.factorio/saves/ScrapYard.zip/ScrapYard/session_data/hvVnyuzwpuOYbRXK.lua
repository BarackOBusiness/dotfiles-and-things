local playsession = {
	{"Menander", {359917}},
	{"laughsofgreed", {213396}},
	{"Eskariot", {120894}},
	{"TiTaN", {294698}},
	{"foo1215321", {235243}},
	{"Mr_T", {265270}},
	{"Ryansplatalt", {11567}},
	{"Reyand", {220154}},
	{"XaLpHa1989", {194198}},
	{"Akhrem", {6423}},
	{"Spaceman-Spiff", {190980}},
	{"Malorie_sXy", {135453}},
	{"iSTEVE", {103299}},
	{"jagger23", {72046}},
	{"Crivvens", {10386}}
}
return playsession