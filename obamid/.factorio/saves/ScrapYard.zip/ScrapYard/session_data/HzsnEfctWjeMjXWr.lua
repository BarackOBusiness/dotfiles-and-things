local playsession = {
	{"NASER", {431814}},
	{"RugbyHunter", {228295}},
	{"SterForever", {270242}},
	{"MontrealCrook", {299454}},
	{"FunghCraft", {170864}},
	{"unixfreak", {282805}},
	{"seeyorise", {211272}},
	{"MrJSelig", {154677}},
	{"cubun_2009", {19681}},
	{"itsnotyouitsme", {966}},
	{"waxman", {1142}},
	{"turk127_ee", {63374}}
}
return playsession