local playsession = {
	{"mewmew", {697250}},
	{"Albombe", {447435}},
	{"Thorgal", {716795}},
	{"p27", {352408}},
	{"Akhrem", {170183}},
	{"morcup", {19571}},
	{"SMikiS", {455993}},
	{"KatanaKiwi", {440237}},
	{"JoaoPinga", {112321}},
	{"JC1223", {991190}},
	{"Sylen", {157733}},
	{"flooxy", {160290}},
	{"dinotromba", {61146}},
	{"Dofolo", {16553}}
}
return playsession