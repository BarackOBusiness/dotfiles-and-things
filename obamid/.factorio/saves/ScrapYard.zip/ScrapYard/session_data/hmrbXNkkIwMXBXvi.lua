local playsession = {
	{"Masterpascoe", {138340}},
	{"Nate66873", {141331}},
	{"brftjx", {100910}},
	{"IgorTime", {982}},
	{"Higgel", {12544}},
	{"Giatros", {48978}},
	{"ksb4145", {43942}},
	{"xenodasein", {3442}},
	{"Kruv", {2013}},
	{"redlabel", {16757}},
	{"Roeno1997", {9848}}
}
return playsession