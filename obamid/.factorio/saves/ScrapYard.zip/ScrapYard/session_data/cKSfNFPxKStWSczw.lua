local playsession = {
	{"Gerkiz", {6930}},
	{"Nikkichu", {14599}},
	{"PTP17", {483}},
	{"Elrael", {1475}},
	{"Xoxlohunter", {155588}},
	{"rocifier", {138007}},
	{"dog80", {60212}},
	{"greattohave", {4866}},
	{"Degg", {46760}},
	{"Rubs10", {37159}}
}
return playsession