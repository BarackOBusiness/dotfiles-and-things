local playsession = {
	{"EPO666", {260522}},
	{"TiTaN", {334288}},
	{"zinoby", {1488}},
	{"NerZurg", {290}},
	{"Lyllakocken", {4695}},
	{"ausmister", {4410}},
	{"Menander", {583192}},
	{"JailsonBR", {399559}},
	{"johnluke93", {19309}},
	{"Taylor3", {270977}},
	{"MuddledBox", {6836}},
	{"PogomanD", {2762}},
	{"Mullacs", {35520}},
	{"Cokezero91", {138895}}
}
return playsession