local playsession = {
	{"PogomanD", {251416}},
	{"Morkol", {8282}},
	{"typphon", {56602}},
	{"BlkKnight", {178836}},
	{"realDonaldTrump", {127120}},
	{"LucidPotato", {9704}},
	{"ehwoghd", {92821}},
	{"Ben2231", {66081}},
	{"Krono", {74088}},
	{"Menander", {69256}},
	{"MontrealCrook", {48407}},
	{"legendary_banana", {9216}},
	{"SpyBot2213", {1254}}
}
return playsession