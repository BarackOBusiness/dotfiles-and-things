local playsession = {
	{"Serennie", {215731}},
	{"Kyte", {215717}},
	{"N355A", {213302}},
	{"ManuelG", {214393}},
	{"robertkruijt", {207948}},
	{"ryabhar", {205295}},
	{"aronwong", {209060}},
	{"Giatros", {198888}},
	{"NASER", {186212}},
	{"haudfl", {33370}},
	{"rlidwka", {142517}},
	{"turk127_ee", {1457}},
	{"Skybreaker", {58208}},
	{"Zorin862", {40814}},
	{"InvertigoHD", {34203}}
}
return playsession