local playsession = {
	{"GdSimOleg", {2550}},
	{"TimmPure", {8476}},
	{"Guitoune", {168114}},
	{"Flashbacks", {166003}},
	{"rlidwka", {113213}},
	{"Styx13", {63420}},
	{"HUONUON", {60230}},
	{"svjatosha", {44985}},
	{"EPO666", {15240}}
}
return playsession