local playsession = {
	{"jobaxter", {2621}},
	{"cawsey21", {1597}},
	{"Ed9210", {579}},
	{"Velguarder", {22517}},
	{"Immo", {1645}},
	{"Menander", {167233}},
	{"fomorenom", {47269}},
	{"tykak", {129846}},
	{"TXL_PLAYZ", {124458}},
	{"Frittenmain", {1784}},
	{"Velldanas", {33221}},
	{"15944831778", {52736}},
	{"matam666", {76797}},
	{"davemaaan", {65904}}
}
return playsession