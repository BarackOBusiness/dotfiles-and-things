local playsession = {
	{"MontrealCrook", {180425}},
	{"dingusdonkey", {358683}},
	{"Styx13", {356160}},
	{"greggk124", {344530}},
	{"wildgrim", {356675}},
	{"rlidwka", {351283}},
	{"Blakcsock", {16107}},
	{"bobbythebob12", {260465}},
	{"Muckknuckle", {14419}},
	{"kovus", {9080}},
	{"ersu", {253121}},
	{"Discotek", {180486}},
	{"ClassAction", {1306}},
	{"jjohny", {44717}},
	{"redgerr", {3827}}
}
return playsession