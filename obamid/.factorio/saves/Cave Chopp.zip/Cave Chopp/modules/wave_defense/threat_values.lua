return {
	["behemoth-biter"] = 24,
	["behemoth-spitter"] = 24,
	["big-biter"] = 8,
	["big-spitter"] = 8,
	["medium-biter"] = 4,
	["medium-spitter"] = 4,
	["small-biter"] = 1,
	["small-spitter"] = 1,
	["small-worm-turret"] = 32,		
	["medium-worm-turret"] = 48,		
	["big-worm-turret"] = 64,		
	["behemoth-worm-turret"] = 80,
}