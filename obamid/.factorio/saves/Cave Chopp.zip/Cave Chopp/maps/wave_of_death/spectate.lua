local function spectate_button()
end

local function on_gui_click()
end

event.add(defines.events.on_gui_click, on_gui_click)
