# ComfyFactorio
A factorio scenario.

How to install and choose a map:
1. Clone or Download the whole repository.
2. Copy the extracted folder into your scenario folder. (../factorio/scenarios/comfyfactorio)
3. Choose a map to play by opening control.lua with your favorite text editor.
4. Find the line "---- enable maps here ----" and remove the "--" in front of the map that you want to activate.
    Make sure only 1 map is activated.    
5. Launch it in the game: >>Play >>Scenarios