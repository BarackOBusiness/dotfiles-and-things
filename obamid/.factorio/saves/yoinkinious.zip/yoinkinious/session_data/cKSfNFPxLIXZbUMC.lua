local playsession = {
	{"Gerkiz", {6930}},
	{"Mullacs", {449}},
	{"Olekplane1", {622071}},
	{"kaimix", {745032}},
	{"Revar", {718}},
	{"RasmusNord", {311201}},
	{"AbsoluteZeroIs0K", {17197}},
	{"Immo", {221822}},
	{"SumerSoft", {27054}},
	{"wekkka", {50298}},
	{"Giatros", {5283}},
	{"Tornado_05", {1244}},
	{"Ed9210", {266997}},
	{"dog80", {21261}},
	{"alven01", {35575}},
	{"CmonMate497", {221351}},
	{"Piewdennis", {8388}}
}
return playsession