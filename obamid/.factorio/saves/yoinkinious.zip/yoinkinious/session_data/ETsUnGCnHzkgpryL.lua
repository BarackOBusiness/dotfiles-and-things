local playsession = {
	{"exabyte", {234113}},
	{"TiTaN", {151390}},
	{"everLord", {412395}},
	{"snoetje", {40632}},
	{"johnluke93", {1664}},
	{"realDonaldTrump", {3841}},
	{"Menander", {54682}},
	{"foggyliziouz", {41559}},
	{"rlidwka", {11957}},
	{"mad58max", {5906}}
}
return playsession