local playsession = {
	{"cawsey21", {251860}},
	{"belbo", {250547}},
	{"scotty2586", {15169}},
	{"jbro1231", {207518}},
	{"Miteone", {236930}},
	{"CmonMate497", {45963}},
	{"Menander", {228476}},
	{"Clevlore", {224411}},
	{"Aerick", {204651}},
	{"PotShot", {4016}},
	{"ExError", {54593}},
	{"7Haydz7", {40444}},
	{"qeteq", {38356}},
	{"Horoperk", {29039}},
	{"realDonaldTrump", {28427}}
}
return playsession