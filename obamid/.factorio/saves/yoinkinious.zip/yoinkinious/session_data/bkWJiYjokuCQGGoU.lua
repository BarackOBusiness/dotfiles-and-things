local playsession = {
	{"DKarma", {251957}},
	{"CawaEast", {251554}},
	{"wakanarai", {249632}},
	{"Vogrov", {1687}},
	{"matam666", {187726}},
	{"4ort", {178551}},
	{"mazamaza", {6100}},
	{"ktrc199", {5556}},
	{"_Lightning", {129625}},
	{"Flashbacks", {111978}},
	{"rlidwka", {19559}}
}
return playsession