local playsession = {
	{"petecomplete", {84481}},
	{"bornii", {83880}},
	{"xxsevenevesxx", {126398}},
	{"Piewdennis", {117945}},
	{"banakeg", {110761}},
	{"Olekplane1", {95760}},
	{"14nickel", {61462}},
	{"Nikkichu", {76454}},
	{"BallisticGamer04", {73535}},
	{"Higgel", {47001}},
	{"Keo_nix", {44262}},
	{"t_Mind", {43241}},
	{"Vancleave", {42800}}
}
return playsession