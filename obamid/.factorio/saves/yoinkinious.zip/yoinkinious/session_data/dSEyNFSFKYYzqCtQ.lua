local playsession = {
	{"Malorie_sXy", {107955}},
	{"Spaceman-Spiff", {106772}},
	{"Mr_T", {106097}},
	{"Reyand", {105464}},
	{"Menander", {105305}},
	{"Sarkani", {66955}},
	{"robertkruijt", {44947}},
	{"Tamika", {42473}},
	{"GarretShadow", {24229}},
	{"wot_tak", {14615}},
	{"TiTaN", {6451}},
	{"ThatOneDudeInPublic", {5794}},
	{"iSTEVE", {2276}}
}
return playsession