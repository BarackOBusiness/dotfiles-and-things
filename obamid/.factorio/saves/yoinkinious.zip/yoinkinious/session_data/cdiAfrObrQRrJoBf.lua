local playsession = {
	{"Krono", {1007972}},
	{"PogomanD", {997781}},
	{"BlkKnight", {994749}},
	{"captaintickles", {11624}},
	{"Factorian12321", {836348}},
	{"Fudster", {52911}},
	{"VorceShard", {197508}},
	{"DynamicDesign", {210016}},
	{"realDonaldTrump", {33627}},
	{"FooRudy", {42602}}
}
return playsession