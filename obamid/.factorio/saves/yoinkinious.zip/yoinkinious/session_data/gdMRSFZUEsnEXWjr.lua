local playsession = {
	{"Savaged", {5401}},
	{"iReed", {499398}},
	{"der_Nase_nach", {269294}},
	{"rocifier", {355038}},
	{"Bill_Nye_1", {303}},
	{"cawsey21", {134655}},
	{"PugGaming", {129503}},
	{"soulreap", {91365}},
	{"KIRkomMAX", {359973}},
	{"jeast360", {204619}},
	{"tykak", {232678}},
	{"nixCorvus", {1383}},
	{"marklinCZ", {52232}},
	{"odgaar", {106539}},
	{"dangomushi", {5675}},
	{"AurelienG", {257652}},
	{"Malondro", {12949}},
	{"Wesoly1234", {6360}},
	{"DKarma", {296}}
}
return playsession