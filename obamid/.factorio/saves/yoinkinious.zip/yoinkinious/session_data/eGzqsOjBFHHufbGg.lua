local playsession = {
	{"gearmach1ne", {38937}},
	{"Miteone", {35116}},
	{"Horoperk", {4278}},
	{"ersu", {1237}},
	{"akrause", {336042}},
	{"Menander", {299320}},
	{"slyboogy", {198652}},
	{"Krengrus", {6920}},
	{"RaccoonBandit", {66629}}
}
return playsession