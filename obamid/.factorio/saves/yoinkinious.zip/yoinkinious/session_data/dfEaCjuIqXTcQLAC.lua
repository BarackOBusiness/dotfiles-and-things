local playsession = {
	{"Dimava", {60634}},
	{"tykak", {71139}},
	{"KIRkomMAX", {70151}},
	{"Nate66873", {69539}},
	{"XAticAtacX", {69279}},
	{"Kirdiaga", {50961}},
	{"Shyrr", {9599}}
}
return playsession