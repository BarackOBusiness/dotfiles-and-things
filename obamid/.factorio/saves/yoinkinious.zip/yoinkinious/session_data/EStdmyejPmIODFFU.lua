local playsession = {
	{"mewmew", {198811}},
	{"I_dream_of_corn", {124763}},
	{"Mattisso", {143990}},
	{"MontrealCrook", {93186}},
	{"Menander", {17949}},
	{"zimny11", {5611}},
	{"acurazine", {1795}},
	{"rlidwka", {7558}},
	{"TimSekys", {112815}},
	{"Porg", {9773}},
	{"CommanderFrog", {7463}},
	{"Schallfalke", {82088}},
	{"lordon11", {1442}},
	{"ETK03", {65005}},
	{"Altaric", {2733}},
	{"IAmTog", {1836}},
	{"Factorian12321", {2974}}
}
return playsession