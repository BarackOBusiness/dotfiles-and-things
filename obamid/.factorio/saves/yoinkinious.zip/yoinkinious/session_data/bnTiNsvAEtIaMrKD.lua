local playsession = {
	{"DKarma", {179949}},
	{"mewmew", {11086}},
	{"rikkert", {2200}},
	{"CawaEast", {174476}},
	{"Firewall5000", {171117}},
	{"DamianMMC", {421}},
	{"BloodWolfmann", {92219}},
	{"MrJSelig", {578}},
	{"Vogrov", {108756}},
	{"Krengrus", {150339}},
	{"wakanarai", {138248}},
	{"EPO666", {107454}},
	{"bobbythebob12", {17446}},
	{"waxman", {10930}}
}
return playsession