local playsession = {
	{"realDonaldTrump", {435}},
	{"KIRkomMAX", {39891}},
	{"aokschopper", {1309}},
	{"rocifier", {204103}},
	{"Ha9p", {200406}},
	{"MasjazZ", {146231}},
	{"EricGott", {2467}},
	{"Headhunter33333", {129769}},
	{"ManuelG", {1370}},
	{"xlDovahkinglx", {96960}}
}
return playsession