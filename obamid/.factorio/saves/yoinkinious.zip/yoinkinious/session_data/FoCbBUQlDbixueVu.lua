local playsession = {
	{"mpovas", {85874}},
	{"Eagle34", {87888}},
	{"blondydex", {130741}},
	{"DerFactorioNinja", {129277}},
	{"KingKolla", {672}},
	{"Artamiel", {116062}},
	{"huanying", {102073}},
	{"TilenT2", {41832}},
	{"aronwong", {98571}},
	{"Zorin862", {78040}},
	{"ManuelG", {13495}},
	{"BloodWolfmann", {60244}},
	{"vedolv", {63809}},
	{"Tony3D", {22345}},
	{"Serennie", {4171}}
}
return playsession