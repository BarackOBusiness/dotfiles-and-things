local playsession = {
	{"Flashbacks", {107888}},
	{"CawaEast", {107201}},
	{"_Lightning", {18873}},
	{"mewmew", {65616}},
	{"Factorian12321", {32420}},
	{"DKarma", {83877}},
	{"matam666", {64396}},
	{"goalie7960", {58363}},
	{"alyptica", {28728}},
	{"rikkert", {9516}}
}
return playsession