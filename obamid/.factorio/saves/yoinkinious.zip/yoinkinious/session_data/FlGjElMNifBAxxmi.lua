local playsession = {
	{"MontrealCrook", {149240}},
	{"Lestibornes", {251373}},
	{"davidbutora", {250566}},
	{"aniche", {250499}},
	{"Tony_2083", {161317}},
	{"Terabite27", {245658}},
	{"Branickin", {89573}},
	{"realDonaldTrump", {231837}},
	{"CVex2150J", {225374}},
	{"mewmew", {209877}},
	{"firstandlast", {182994}},
	{"Daysees", {180484}},
	{"ETK03", {8117}},
	{"MuddledBox", {25381}},
	{"tickterd", {171547}},
	{"rocifier", {155336}},
	{"taroxyz", {144914}},
	{"OzfurAtlas", {94405}},
	{"emperorhawk", {23484}},
	{"numberoverzero", {8156}},
	{"zhu001", {25261}}
}
return playsession