local playsession = {
	{"dr_root", {1055}},
	{"Miteone", {430357}},
	{"belbo", {429442}},
	{"JB_Delta", {422181}},
	{"omgrun", {250973}},
	{"codog2", {384130}},
	{"Paraplegic_Ape", {51514}},
	{"4rchangel", {334709}},
	{"Menander", {304854}},
	{"realDonaldTrump", {273389}},
	{"bigot", {195933}},
	{"Kronberry", {1188}},
	{"RebuffedBrute44", {188879}},
	{"datadrian", {152125}},
	{"Generalpluto3", {3268}},
	{"Ed9210", {68142}},
	{"Terarink", {4002}},
	{"slowcrazy54", {46746}},
	{"ViciousDis", {4529}},
	{"samrrr", {7328}}
}
return playsession