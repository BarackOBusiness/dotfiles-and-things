local playsession = {
	{"WeedyKiller", {107970}},
	{"mewmew", {101704}},
	{"Elrael", {100814}},
	{"22TwentyTwo", {50491}},
	{"KickassLee", {39141}},
	{"Rasti", {6226}}
}
return playsession