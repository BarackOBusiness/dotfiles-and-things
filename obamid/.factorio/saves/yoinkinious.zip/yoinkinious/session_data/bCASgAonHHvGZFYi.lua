local playsession = {
	{"teomarx", {286162}},
	{"rlidwka", {5593}},
	{"D0pex", {184431}},
	{"mewmew", {48787}},
	{"Xlicity", {2598}},
	{"RugbyHunter", {64332}},
	{"WorldofWarIII", {60989}},
	{"POWXJASON", {1306}},
	{"phanton5000", {14504}},
	{"Krono", {2688}},
	{"NappingYG", {5719}}
}
return playsession