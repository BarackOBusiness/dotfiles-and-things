local playsession = {
	{"Gerkiz", {179915}},
	{"Kruv", {156422}},
	{"phanton5000", {131278}},
	{"gearmach1ne", {130090}},
	{"matam666", {106290}},
	{"Jhondoe", {115287}},
	{"dorpdorp", {68605}},
	{"NappingYG", {37075}},
	{"Zorzzz", {31858}},
	{"tickterd", {24403}}
}
return playsession