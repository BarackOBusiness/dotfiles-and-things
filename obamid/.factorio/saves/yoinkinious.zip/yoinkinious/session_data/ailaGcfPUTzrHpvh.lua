local playsession = {
	{"Bull", {558172}},
	{"banakeg", {156028}},
	{"MontrealCrook", {340404}},
	{"rlidwka", {574979}},
	{"Styx13", {177054}},
	{"greggk124", {231019}},
	{"Soul_king3066", {569384}},
	{"EigenMan", {226050}},
	{"ronbonator", {292699}},
	{"sobitome", {251459}},
	{"TBob", {34547}},
	{"LtDerp", {252329}},
	{"engbizzle", {71254}},
	{"Spiritmorin", {322628}},
	{"NASER", {305952}},
	{"syntaxers", {8932}},
	{"ZumbieHater", {4582}},
	{"BadSpeiling", {122298}},
	{"xkillolz", {108256}},
	{"SawdustInvader", {63224}},
	{"corbin9228", {21784}}
}
return playsession