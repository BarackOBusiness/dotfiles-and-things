return function(center, surface) --small oil setup
    local ce = surface.create_entity --save typing
    local fN = game.forces.neutral
    local direct = defines.direction
    local e = surface.create_entity({name = "storage-tank", position = {center.x + (1.0), center.y + (-3.0)}, force = fN, direction = math.random(0, 3)})
    local fluids = {"crude-oil", "lubricant", "heavy-oil", "light-oil", "petroleum-gas", "sulfuric-acid", "water"}
    e.fluidbox[1] = {name = fluids[math.random(1, #fluids)], amount = math.random(15000, 25000)}

    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (-4.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-4.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-1.0), center.y + (-5.0)}, force = fN}
    ce{name = "storage-tank", position = {center.x + (1.0), center.y + (-3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (0.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (1.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (3.0), center.y + (-4.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (2.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (3.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (-5.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (-4.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (-2.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (-3.0)}, force = fN}
    ce{name = "storage-tank", position = {center.x + (-2.0), center.y + (-2.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (3.0), center.y + (-3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (-3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (0.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (-1.0)}, force = fN}
    ce{name = "pipe-to-ground", position = {center.x + (1.0), center.y + (0.0)}, force = fN}
    ce{name = "pipe", position = {center.x + (0.0), center.y + (-1.0)}, force = fN}
    ce{name = "pipe", position = {center.x + (1.0), center.y + (-1.0)}, force = fN}
    ce{name = "pipe", position = {center.x + (2.0), center.y + (-1.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (0.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (2.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (1.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (1.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (2.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-5.0), center.y + (3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (-4.0), center.y + (3.0)}, force = fN}
    ce{name = "pipe-to-ground", position = {center.x + (1.0), center.y + (4.0)}, direction = direct.south, force = fN}
    ce{name = "stone-wall", position = {center.x + (1.0), center.y + (3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (0.0), center.y + (3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (3.0), center.y + (3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (2.0), center.y + (3.0)}, force = fN}
    ce{name = "stone-wall", position = {center.x + (4.0), center.y + (3.0)}, force = fN}
end
