require("mod-gui")
require("prototypes.startup")
