local default_style = data.raw["gui-style"].default

default_style.ACTR_small_sprite = {
  type = "image_style",
  stretch_image_to_widget_size = true,
  size = 16
}
