data:extend({
{
    type = "double-setting",
    name = "ACTR-Multiplier",
    setting_type = 'runtime-per-user',
    minimum_value = 1,
    default_value = 100
}}
)